#' @S3method plot sim.bprobit
plot.sim.bprobit <- plot.sim.blogit
