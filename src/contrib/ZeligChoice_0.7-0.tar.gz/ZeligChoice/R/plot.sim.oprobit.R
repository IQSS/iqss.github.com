#' @S3method plot sim.oprobit
plot.sim.oprobit <- plot.sim.ologit
