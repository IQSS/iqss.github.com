#' @S3method param probit.mixed
param.probit.mixed <- param.logit.mixed
