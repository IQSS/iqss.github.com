#' @S3method qi probit.mixed
qi.probit.mixed <- qi.logit.mixed
