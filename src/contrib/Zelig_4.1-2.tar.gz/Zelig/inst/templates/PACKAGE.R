#' \\package\\
#' 
#' \tabular{ll}{
#'   Package: \tab \\package\\\cr
#'   Version: \tab 0.1\cr
#'   Date: \tab 2011-04-25\cr
#'   Depends: \\depends\\
#'   License: \tab GPL version 2 or newer\cr
#' }
#'
#' Edit this description
#'
#' @name \\package\\-package
#' @aliases \\package\\-package \\package\\
#' @docType package
#' @importFrom Zelig describe param qi
#' @author \\author\\
#' @keywords package
NULL

