library(Zelig)

data(turnout)

par(mfrow=c(3,3))

z <- zelig(vote ~ income + educate, model="logit", data=turnout)
x <- setx(z, educate=2:23)
s <- sim(z, x)

plot.ci(s, var="educate")
plot.ci(s, ylim=c(.2, .3), var="educate")
plot.ci(s, main = "FUCK IT ", var="educate")
plot.ci(s, main = "FUCK IT ", sub = "For real", var="educate")
plot.ci(s, xlab="okay", main = "FUCK IT ", sub = "For real", var="educate")
plot.ci(s, ylab="no", main = "FUCK IT ", sub = "For real", var="educate")
