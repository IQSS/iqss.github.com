library(Zelig)
data(turnout)

z <- zelig(vote ~ race + educate, model = "ls", data = turnout)
x <- setx(z, educate = -100:-90)
s <- sim(z, x)
plot.ci(s, var = "educate")

